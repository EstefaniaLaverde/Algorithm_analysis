from queue import Queue
import sys

class FacebookNetwork:
    def __init__(self, users: list[int], friends: list[tuple[int,int]]):
        """
        Inicializa una red social con usuarios y sus amistades.

        Inicializa una red social con una lista de usuarios y sus amistades. Los usuarios se almacenan en un conjunto para una adición o eliminación eficiente de usuarios en futuras implementaciones. Las amistades se almacenan en un diccionario donde cada usuario se asigna a un conjunto de sus amigos, de la misma manera, permitiendo una adición o eliminación eficiente de amistades en futuras implementaciones. 

        Parameters:
        users (list[int]): Una lista de usuarios.
        friends (list[tuple[int,int]]): Una lista de amistades, donde cada amistad es una tupla de dos usuarios.
        """

        self.users=set(users)
        self.friends={user:set() for user in users}
        for user1,user2 in friends:
            # las amistades son bidireccionales, por lo que se agregan a los conjuntos de amigos de ambos usuarios
            self.friends[user1].add(user2)
            self.friends[user2].add(user1)

    def check6degrees(self, max_level: int = 6) -> bool:
        """
        Verifica si la red social cumple con la teoría de los seis grados de separación.

        Este método realiza un recorrido en anchura (BFS) de la red social, comenzando desde cada usuario. Verifica si todos los usuarios pueden ser alcanzados dentro de un máximo grado de separación especificado por defecto siendo 6. Si algún usuario excede este límite o si la red est disconexa, el método devuelve False. De lo contrario, devuelve True.

        Parameters:
        max_level (int): El máximo grado de separación a verificar. Por defecto es 6.

        Returns:
        bool: True si la red social cumple con la teoría de los seis grados de separación y es conexa, False en caso contrario.
        """
        # Inicialización de variables para verificar las condiciones
        exceeds_max_levels = False
        is_disconnected = False
        
        # Itera sobre cada usuario en la red social
        for root_user in self.users:

            # Inicializa un conjunto para mantener un registro de los usuarios visitados y una cola para el BSF
            visited = set()
            queue = Queue()

            # Agrega el root_user al conjunto de visitados y a la cola (con el nivel inicial 0)
            visited.add(root_user)
            queue.put([root_user, 0])

            # Realiza el recorrido en anchura
            while not queue.empty():
                selected, level = queue.get()
                
                # Itera sobre los amigos del usuario actual
                for friend in self.friends[selected]:
                    # Si el amigo no ha sido visitado antes, agréguelo a la cola y al conjunto de visitados (aumentando el nivel)
                    if friend not in visited:
                        queue.put([friend, level + 1])
                        visited.add(friend)

                # Verifica si el nivel actual excede el máximo grado de separación especificado
                exceeds_max_levels = level > max_level 

            # Verifica si al final del recorrido en anchura todos los usuarios han sido visitados (conexidad)
            is_disconnected = visited != self.users

            # Si se cumple la condición, rompe el bucle y devuelve False
            if exceeds_max_levels or is_disconnected:
                return False

        # Devuelve True si la red está conectada y ningún usuario excede el nivel máximo
        return True
    

if __name__ == '__main__':
    # Lee el grafo desde un archivo .in con el formato especificado
    with open(sys.argv[1]) as f:
        content = f.read()  
        sections = [section.strip() for section in content.split('\n\n') if section.strip()]  # Divide por dobles saltos de línea y elimina los espacios en blanco

    # Guarda los resultados
    results = []

    # Procesa cada grafo
    for section in sections:
        lines = section.splitlines()  
        nodes = list(map(int, lines[0].split()))  
        m = int(lines[1])  
        edges = []
        for i in range(2, 2 + m):  
            a, b = map(int, lines[i].split())
            edges.append((a, b))

        # Crea la instancia de FacebookNetwork
        G = FacebookNetwork(nodes, edges)

        # Verifica los 6 grados de separación y los guarda
        result = G.check6degrees()
        results.append(result)
        print(result)

        # Guarda los resultados en un archivo .out
        with open(sys.argv[2], 'w') as f:
            for result in results:
                f.write(str(result) + '\n')